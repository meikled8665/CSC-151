import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class calculator2 extends JFrame implements ActionListener {
    private JTextField[] fields = new JTextField[4];
    private JButton calculateButton;
    private JButton clearButton;
    private JLabel resultLabel;
    private String userName;

    public calculator2(String name) {
        this.userName = name;
        setTitle("Sum Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(550, 550);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(245, 245, 250));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 13);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);

        JLabel titleLabel = new JLabel("Sum of Four Numbers");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(40, 40, 50));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(titleLabel, gbc);
        gbc.gridwidth = 1;

        for (int i = 0; i < 4; i++) {
            JLabel label = new JLabel("Number " + (i + 1) + ":");
            label.setFont(labelFont);
            label.setForeground(new Color(60, 60, 70));
            gbc.gridx = 0;
            gbc.gridy = i + 1;
            gbc.anchor = GridBagConstraints.WEST;
            mainPanel.add(label, gbc);

            fields[i] = new JTextField(15);
            fields[i].setFont(inputFont);
            fields[i].setBackground(Color.WHITE);
            fields[i].setForeground(new Color(40, 40, 50));
            fields[i].setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, new Color(100, 150, 255)));
            fields[i].setPreferredSize(new Dimension(250, 45));
            gbc.gridx = 1;
            mainPanel.add(fields[i], gbc);
        }

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        buttonPanel.setBackground(new Color(245, 245, 250));

        calculateButton = new JButton("Calculate Sum");
        calculateButton.setFont(buttonFont);
        calculateButton.setForeground(Color.WHITE);
        calculateButton.setBackground(new Color(100, 150, 255));
        calculateButton.setBorderPainted(false);
        calculateButton.setFocusPainted(false);
        calculateButton.setPreferredSize(new Dimension(140, 40));
        calculateButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        calculateButton.addActionListener(this);
        buttonPanel.add(calculateButton);

        clearButton = new JButton("Clear");
        clearButton.setFont(buttonFont);
        clearButton.setForeground(Color.WHITE);
        clearButton.setBackground(new Color(150, 150, 150));
        clearButton.setBorderPainted(false);
        clearButton.setFocusPainted(false);
        clearButton.setPreferredSize(new Dimension(100, 40));
        clearButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clearButton.addActionListener(this);
        buttonPanel.add(clearButton);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 10, 10);
        mainPanel.add(buttonPanel, gbc);

        JLabel resultLabelText = new JLabel("Sum: ");
        resultLabelText.setFont(new Font("Segoe UI", Font.BOLD, 16));
        resultLabelText.setForeground(new Color(50, 120, 50));
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(10, 10, 10, 5);
        mainPanel.add(resultLabelText, gbc);

        resultLabel = new JLabel("0.0");
        resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        resultLabel.setForeground(new Color(50, 120, 50));
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(resultLabel, gbc);

        setContentPane(mainPanel);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                showThemedThankYouDialog();
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calculateButton) {
            try {
                double sum = 0;
                for (JTextField field : fields) {
                    sum += Double.parseDouble(field.getText().trim());
                }
                resultLabel.setText(String.format("%.2f", sum));
            } catch (NumberFormatException ex) {
                showThemedErrorDialog(this);
            }
        } else if (e.getSource() == clearButton) {
            for (JTextField field : fields) {
                field.setText("");
            }
            resultLabel.setText("0.0");
        }
    }

    private void showThemedErrorDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Invalid Input", true);
        dialog.setSize(350, 150);
        dialog.setLocationRelativeTo(parent);
        dialog.setResizable(false);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 245, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setLayout(new BorderLayout(10, 10));

        JLabel messageLabel = new JLabel("Please enter valid numbers.");
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        messageLabel.setForeground(new Color(60, 60, 70));
        panel.add(messageLabel, BorderLayout.CENTER);

        JButton okButton = new JButton("OK");
        okButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        okButton.setForeground(Color.WHITE);
        okButton.setBackground(new Color(100, 150, 255));
        okButton.setBorderPainted(false);
        okButton.setFocusPainted(false);
        okButton.setPreferredSize(new Dimension(80, 35));
        okButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        okButton.addActionListener(ev -> dialog.dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(245, 245, 250));
        buttonPanel.add(okButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private void showThemedThankYouDialog() {
        JDialog dialog = new JDialog(this, "Thank You", true);
        dialog.setSize(400, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 245, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        panel.setLayout(new BorderLayout(10, 15));

        JLabel messageLabel = new JLabel("Thank you, " + userName + "!");
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        messageLabel.setForeground(new Color(50, 120, 50));
        messageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(messageLabel, BorderLayout.CENTER);

        JButton okButton = new JButton("OK");
        okButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        okButton.setForeground(Color.WHITE);
        okButton.setBackground(new Color(100, 150, 255));
        okButton.setBorderPainted(false);
        okButton.setFocusPainted(false);
        okButton.setPreferredSize(new Dimension(80, 35));
        okButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        okButton.addActionListener(ev -> {
            dialog.dispose();
            System.exit(0);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(245, 245, 250));
        buttonPanel.add(okButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }

    private static String showThemedWelcomeDialog() {
        JDialog dialog = new JDialog((JFrame) null, "Welcome", true);
        dialog.setSize(450, 220);
        dialog.setLocationRelativeTo(null);
        dialog.setResizable(false);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(245, 245, 250));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Welcome!");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(40, 40, 50));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel promptLabel = new JLabel("Please enter your name:");
        promptLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        promptLabel.setForeground(new Color(60, 60, 70));
        promptLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(promptLabel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JTextField nameField = new JTextField(20);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        nameField.setBackground(Color.WHITE);
        nameField.setForeground(new Color(40, 40, 50));
        nameField.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, new Color(100, 150, 255)));
        nameField.setMaximumSize(new Dimension(300, 40));
        mainPanel.add(nameField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(new Color(245, 245, 250));

        String[] result = new String[1];
        result[0] = null;

        JButton okButton = new JButton("OK");
        okButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        okButton.setForeground(Color.WHITE);
        okButton.setBackground(new Color(100, 150, 255));
        okButton.setBorderPainted(false);
        okButton.setFocusPainted(false);
        okButton.setPreferredSize(new Dimension(80, 35));
        okButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        okButton.addActionListener(ev -> {
            String name = nameField.getText().trim();
            if (!name.isEmpty()) {
                result[0] = name;
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Please enter a name.", "Input Required", JOptionPane.WARNING_MESSAGE);
            }
        });
        buttonPanel.add(okButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setBackground(new Color(150, 150, 150));
        cancelButton.setBorderPainted(false);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(80, 35));
        cancelButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cancelButton.addActionListener(ev -> dialog.dispose());
        buttonPanel.add(cancelButton);

        mainPanel.add(buttonPanel);
        dialog.setContentPane(mainPanel);
        dialog.setVisible(true);

        return result[0];
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // If system L&F is not available, use default
        }
        String name = showThemedWelcomeDialog();
        if (name != null && !name.isEmpty()) {
            SwingUtilities.invokeLater(() -> new calculator2(name).setVisible(true));
        } else if (name == null) {
            // User cancelled the dialog
            System.exit(0);
        }
    }
}
