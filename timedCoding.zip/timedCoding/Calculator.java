import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator {
    public static int calculate(int num1, int num2) {
        return num1 + num2;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGui());
    }

    private static void createAndShowGui() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        JFrame frame = new JFrame("Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 450);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(245, 245, 250));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 13);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);

        JLabel titleLabel = new JLabel("Add Two Numbers");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(40, 40, 50));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        mainPanel.add(titleLabel, gbc);
        gbc.gridwidth = 1;

        JLabel label1 = new JLabel("Number 1:");
        label1.setFont(labelFont);
        label1.setForeground(new Color(60, 60, 70));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(label1, gbc);

        JTextField field1 = new JTextField(15);
        field1.setFont(inputFont);
        field1.setBackground(Color.WHITE);
        field1.setForeground(new Color(40, 40, 50));
        field1.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, new Color(100, 150, 255)));
        field1.setPreferredSize(new Dimension(250, 45));
        gbc.gridx = 1;
        mainPanel.add(field1, gbc);

        JLabel label2 = new JLabel("Number 2:");
        label2.setFont(labelFont);
        label2.setForeground(new Color(60, 60, 70));
        gbc.gridx = 0;
        gbc.gridy = 2;
        mainPanel.add(label2, gbc);

        JTextField field2 = new JTextField(15);
        field2.setFont(inputFont);
        field2.setBackground(Color.WHITE);
        field2.setForeground(new Color(40, 40, 50));
        field2.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, new Color(100, 150, 255)));
        field2.setPreferredSize(new Dimension(250, 45));
        gbc.gridx = 1;
        mainPanel.add(field2, gbc);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.setFont(buttonFont);
        calculateButton.setForeground(Color.WHITE);
        calculateButton.setBackground(new Color(100, 150, 255));
        calculateButton.setBorderPainted(false);
        calculateButton.setFocusPainted(false);
        calculateButton.setPreferredSize(new Dimension(160, 40));
        calculateButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 10, 10);
        mainPanel.add(calculateButton, gbc);

        JLabel resultLabel = new JLabel("Result: ");
        resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        resultLabel.setForeground(new Color(50, 120, 50));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        mainPanel.add(resultLabel, gbc);

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int num1 = Integer.parseInt(field1.getText().trim());
                    int num2 = Integer.parseInt(field2.getText().trim());
                    int result = calculate(num1, num2);
                    resultLabel.setText("Result: " + result);
                } catch (NumberFormatException ex) {
                    showThemedErrorDialog(frame);
                }
            }
        });

        frame.setContentPane(mainPanel);
        frame.setVisible(true);
    }

    private static void showThemedErrorDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Invalid Input", true);
        dialog.setSize(350, 150);
        dialog.setLocationRelativeTo(parent);
        dialog.setResizable(false);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 245, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panel.setLayout(new BorderLayout(10, 10));

        JLabel messageLabel = new JLabel("Please enter valid integers.");
        messageLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        messageLabel.setForeground(new Color(60, 60, 70));
        panel.add(messageLabel, BorderLayout.CENTER);

        JButton okButton = new JButton("OK");
        okButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        okButton.setForeground(Color.WHITE);
        okButton.setBackground(new Color(100, 150, 255));
        okButton.setBorderPainted(false);
        okButton.setFocusPainted(false);
        okButton.setPreferredSize(new Dimension(80, 35));
        okButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        okButton.addActionListener(e -> dialog.dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(245, 245, 250));
        buttonPanel.add(okButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }
}
